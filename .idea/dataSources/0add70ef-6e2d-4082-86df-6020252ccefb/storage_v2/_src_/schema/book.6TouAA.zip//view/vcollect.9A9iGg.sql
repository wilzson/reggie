create view vcollect as
select `book`.`collect`.`collectID` AS `collectID`,
       `book`.`collect`.`book_id`   AS `book_id`,
       `book`.`book`.`book_pic`     AS `book_pic`,
       `book`.`collect`.`email`     AS `email`,
       `book`.`collect`.`num`       AS `num`,
       `book`.`book`.`book_class`   AS `book_class`,
       `book`.`book`.`book_name`    AS `book_name`,
       `book`.`book`.`book_price`   AS `book_price`,
       `book`.`book`.`book_info`    AS `book_info`
from (`book`.`collect`
         join `book`.`book`)
where (`book`.`book`.`book_id` = `book`.`collect`.`book_id`);

