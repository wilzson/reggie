create view vcart as
select `book`.`cart`.`cartID`     AS `cartID`,
       `book`.`cart`.`book_id`    AS `book_id`,
       `book`.`book`.`book_pic`   AS `book_pic`,
       `book`.`cart`.`email`      AS `email`,
       `book`.`cart`.`num`        AS `num`,
       `book`.`book`.`book_name`  AS `book_name`,
       `book`.`book`.`book_price` AS `book_price`
from (`book`.`cart`
         join `book`.`book`)
where (`book`.`book`.`book_id` = `book`.`cart`.`book_id`);

