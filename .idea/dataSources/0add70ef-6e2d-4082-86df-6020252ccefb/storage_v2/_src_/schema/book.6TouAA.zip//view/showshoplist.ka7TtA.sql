create view showshoplist as
select `a`.`orderID`    AS `orderID`,
       `a`.`SLID`       AS `SLID`,
       `a`.`num`        AS `num`,
       `a`.`email`      AS `email`,
       `a`.`book_id`    AS `book_id`,
       `b`.`book_name`  AS `book_name`,
       `b`.`book_pic`   AS `book_pic`,
       `b`.`book_price` AS `book_price`,
       `b`.`your_price` AS `your_price`
from (`book`.`shoplist` `a`
         join `book`.`book` `b`)
where (`a`.`book_id` = `b`.`book_id`);

