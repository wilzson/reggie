create view showorder as
select `book`.`myorder`.`orderID`    AS `orderID`,
       `book`.`myorder`.`email`      AS `email`,
       `book`.`myorder`.`kddh`       AS `kddh`,
       `book`.`myorder`.`inputtime`  AS `inputtime`,
       `book`.`customer`.`sname`     AS `sname`,
       `book`.`customer`.`address`   AS `address`,
       `book`.`myorder`.`fkfs`       AS `fkfs`,
       `book`.`myorder`.`shifu`      AS `shifu`,
       `book`.`myorder`.`peisongday` AS `peisongday`,
       `book`.`myorder`.`ddzt`       AS `ddzt`
from (`book`.`myorder`
         join `book`.`customer`)
where (`book`.`myorder`.`custID` = `book`.`customer`.`custID`)
order by `book`.`myorder`.`peisongday` desc, `book`.`myorder`.`orderID` desc;

